Rx1=1000  # 1k orm
Rx2=9300  # 9.3k orm
Cx1=0.00000000053  # 530pF

A = Rx2/(Rx1*Cx1)

R=[1,2,3,9.3,100,1000,9300]

C=[1,2,3,4,53,0.053,0.000053,0.00000000053]

for R1 in R:
    for R2 in R:
        for C1 in C:
            a = R2/(R1*C1)
            if a == A:
                print("R1=" + R1)
                print("R2=" + R2)
                print("C1=" + C1)